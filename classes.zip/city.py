from classes import *
from variables import *
import pygame
from definialas import *
from random import randint, choice



